package com.acme.app;


import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class TextBox extends HBox {

        Label myLabel = new Label("Text: ");
        Label input = new Label();
        TextField myTextField = new TextField();

    HBox box = new HBox();

        public TextBox (){
            box.setAlignment(Pos.TOP_CENTER);

            //HBox box = new HBox();
            box.getChildren().addAll(myLabel, myTextField);
            Button submit = new Button("Submit");
            this.getChildren().add(box);
            this.getChildren().add(submit);
            this.getChildren().add(input);

            submit.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent actionEvent) {
                    if (myTextField.getText() != null){

                        input.setText(myTextField.getText());


                    } else{
                        input.setText("You didn't enter anything");
                    }
                }
            });
        }


}
