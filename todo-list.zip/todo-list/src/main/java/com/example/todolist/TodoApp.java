package com.example.todolist;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class TodoApp extends Application {
    private ObservableList<TodoItem> todoItems = FXCollections.observableArrayList();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Todo App");

        ListView<TodoItem> listView = new ListView<>(todoItems);
        listView.setCellFactory(param -> new TodoCell());

        TextField inputField = new TextField();
        inputField.setPromptText("Enter a new task");

        Button addButton = new Button("Add item");
        addButton.setOnAction(event -> {
            String taskText = inputField.getText();
            if (!taskText.isEmpty()) {
                todoItems.add(new TodoItem(taskText));
                inputField.clear();
            }
        });

        HBox.setHgrow(inputField, Priority.ALWAYS);  // Розтягуємо поле введення на весь доступний простір

        HBox inputBox = new HBox(10, inputField, addButton);
        inputBox.setAlignment(Pos.CENTER_RIGHT);
        inputBox.setPadding(new Insets(10));

        Label titleLabel = new Label("Todo List"); // Додаємо надпис
        titleLabel.setStyle("-fx-font-size: 18; -fx-font-weight: bold;"); // Стилізуємо надпис


        VBox root = new VBox(10);
        root.setPadding(new Insets(10));
        root.getChildren().addAll(titleLabel, listView, inputBox);

        Scene scene = new Scene(root, 500, 300);
        scene.getStylesheets().add(getClass().getResource("styles.css").toExternalForm());
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private class TodoItem {
        private String task;
        private boolean completed;

        public TodoItem(String task) {
            this.task = task;
            this.completed = false;
        }

        public String getTask() {
            return task;
        }

        public boolean isCompleted() {
            return completed;
        }

        public void setCompleted(boolean completed) {
            this.completed = completed;
        }
    }

    private class TodoCell extends ListCell<TodoItem> {
        @Override
        protected void updateItem(TodoItem item, boolean empty) {
            super.updateItem(item, empty);

            if (empty || item == null) {
                setText(null);
                setGraphic(null);
            } else {
                CheckBox checkBox = new CheckBox(item.getTask());
                checkBox.setStyle("-fx-font-family: Monospaced; -fx-font-size: 14;");


                checkBox.setSelected(item.isCompleted());
                checkBox.selectedProperty().addListener((observable, oldValue, newValue) -> {
                    item.setCompleted(newValue);
                    updateStyle(item, checkBox);
                });

                updateStyle(item, checkBox);

                setGraphic(new HBox(checkBox));
            }
        }

        private void updateStyle(TodoItem item, CheckBox checkBox) {
            if (item.isCompleted()) {
                checkBox.getStyleClass().add("completed");
            } else {
                checkBox.getStyleClass().remove("completed");
            }
        }

    }
}

